#
#   version.rb - shell version definition file
#       $Release Version: 0.7$
#       $Revision: 38201 $
#       by Keiju ISHITSUKA(keiju@ruby-lang.org)
#
# --
#
#
#

class Shell # :nodoc:
  @RELEASE_VERSION = "0.7"
  @LAST_UPDATE_DATE = "07/03/20"
end
