class Gem::Package::Source # :nodoc:
end

